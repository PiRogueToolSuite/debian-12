import logging
import re
from typing import Optional, List, Dict, TextIO

import grpc
import yaml
from google.protobuf import empty_pb2
from google.protobuf.json_format import MessageToDict, ParseDict
from google.protobuf.wrappers_pb2 import Int32Value, UInt32Value, StringValue

from pirogue_admin_api import system_pb2, system_pb2_grpc
from pirogue_admin_api import services_pb2, services_pb2_grpc
from pirogue_admin_api import network_pb2, network_pb2_grpc
from pirogue_admin_api import access_pb2, access_pb2_grpc

from pirogue_admin_api import (
    PIROGUE_ADMIN_AUTH_HEADER, PIROGUE_ADMIN_AUTH_SCHEME,
    PIROGUE_ADMIN_TCP_PORT)
from pirogue_admin_api.network_pb2 import WifiConfiguration, VPNPeerAddRequest, ClosePortRequest, IsolatedPort, PublicAccessRequest
from pirogue_admin_api.services_pb2 import DashboardConfiguration, SuricataRulesSource, DeviceMonitoring, DeviceMonitoringFilter
from pirogue_admin_api.access_pb2 import (
    ServiceAccess,
    PermissionChanges,
)
from pirogue_admin_client.types import OperatingMode

EMPTY = empty_pb2.Empty()

logger = logging.getLogger(__name__)


class NoPiRogueAdminConnection(BaseException):
    """"""


class ApplyConfigurationError(BaseException):
    """"""


def _inject_token_request(callback: grpc.AuthMetadataPluginCallback,
                          token: Optional[str], error: Optional[Exception]):
    metadata = ((PIROGUE_ADMIN_AUTH_HEADER, '%s %s' % (PIROGUE_ADMIN_AUTH_SCHEME, token)),)
    callback(metadata, error)


class TokenAuthMetadataPlugin(grpc.AuthMetadataPlugin):
    """Metadata wrapper for raw access token credentials."""
    _token: str

    def __init__(self, access_token: str):
        self._token = access_token

    def __call__(self, context: grpc.AuthMetadataContext,
                 callback: grpc.AuthMetadataPluginCallback):
        _inject_token_request(callback, self._token, None)


def access_token_call_credentials(access_token):
    """Construct CallCredentials from an access token.

    Args:
      access_token: A string to place directly in the http request
        authorization header, for example
        "authorization: Token <access_token>".

    Returns:
      A CallCredentials.
    """
    return grpc.metadata_call_credentials(
        TokenAuthMetadataPlugin(access_token), None)


class BaseAdapter:

    def __init__(self, channel):
        pass


class SystemAdapter(BaseAdapter):
    _stub_system: system_pb2_grpc.SystemStub

    def __init__(self, channel):
        super(SystemAdapter, self).__init__(channel)
        self._stub_system = system_pb2_grpc.SystemStub(channel)

    def get_configuration_tree(self):
        answer = self._stub_system.GetConfigurationTree(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def get_configuration(self):
        answer = self._stub_system.GetConfiguration(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        if 'variables' in answer:
            answer = answer['variables']
        return answer

    def get_operating_mode(self):
        answer = self._stub_system.GetOperatingMode(EMPTY)
        return OperatingMode(answer.mode)

    def get_status(self):
        answer = self._stub_system.GetStatus(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def get_packages_info(self):
        answer = self._stub_system.GetPackagesInfo(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        if 'packages' in answer:
            answer = answer['packages']
        return answer

    def get_hostname(self):
        answer = self._stub_system.GetHostname(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def get_locale(self):
        answer = self._stub_system.GetLocale(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def get_timezone(self):
        answer = self._stub_system.GetTimezone(EMPTY)
        answer = MessageToDict(answer)
        return answer


class NetworkAdapter(BaseAdapter):
    _stub_network: network_pb2_grpc.NetworkStub

    def __init__(self, channel):
        super(NetworkAdapter, self).__init__(channel)
        self._stub_network = network_pb2_grpc.NetworkStub(channel)

    def get_wifi_configuration(self):
        answer = self._stub_network.GetWifiConfiguration(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def set_wifi_configuration(self, ssid: str = None, passphrase: str = None, country_code: str = None):
        if ssid is None and passphrase is None and country_code is None:
            raise ValueError('please provide at least one of ssid, passphrase or country_code')
        message = WifiConfiguration()
        if ssid:
            message.ssid = ssid
        if passphrase:
            message.passphrase = passphrase
        if country_code:
            message.country_code = country_code
        logger.debug(f'set_wifi_configuration({message})')
        answer = self._stub_network.SetWifiConfiguration(message)

    def list_vpn_peers(self):
        answer = self._stub_network.ListVPNPeers(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        if 'peers' in answer:
            answer = answer['peers']
        return answer

    def get_vpn_peer(self, idx: int):
        idx_param = Int32Value()
        idx_param.value = int(idx)
        answer = self._stub_network.GetVPNPeer(idx_param)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def get_vpn_peer_config(self, idx: int):
        idx_param = Int32Value()
        idx_param.value = int(idx)
        answer = self._stub_network.GetVPNPeerConfig(idx_param)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def add_vpn_peer(self, comment: str = None, public_key: str = None):
        add_request = VPNPeerAddRequest(comment=comment, public_key=public_key)
        answer = self._stub_network.AddVPNPeer(add_request)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def delete_vpn_peer(self, idx: int):
        idx_param = Int32Value()
        idx_param.value = int(idx)
        answer = self._stub_network.DeleteVPNPeer(idx_param)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def enable_external_public_access(self, domain: str, email: str):
        request = PublicAccessRequest(domain=domain, email=email)
        answer = self._stub_network.EnableExternalPublicAccess(request)

    def disable_external_public_access(self):
        answer = self._stub_network.DisableExternalPublicAccess(EMPTY)

    def list_isolated_open_ports(self):
        answer = self._stub_network.ListIsolatedOpenPorts(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        if 'ports' in answer:
            answer = answer['ports']
        return answer

    def open_isolated_port(self, incoming_port: int, outgoing_port: int = None):
        request = IsolatedPort(port=int(incoming_port))
        if outgoing_port:
            request.destination_port = int(outgoing_port)
        answer = self._stub_network.OpenIsolatedPort(request)

    def close_isolated_port(self, incoming_port: int = None):
        request = ClosePortRequest()
        if incoming_port:
            request.port = int(incoming_port)
        answer = self._stub_network.CloseIsolatedPort(request)

    def list_connected_devices(self):
        answer = self._stub_network.ListConnectedDevices(EMPTY)
        answer = MessageToDict(answer)
        return answer


class ServicesAdapter(BaseAdapter):
    _stub_services: services_pb2_grpc.ServicesStub

    def __init__(self, channel):
        super(ServicesAdapter, self).__init__(channel)
        self._stub_services = services_pb2_grpc.ServicesStub(channel)

    def set_dashboard_configuration(self, password: str):
        request = DashboardConfiguration(password=password)
        answer = self._stub_services.SetDashboardConfiguration(request)

    def get_dashboard_configuration(self):
        answer = self._stub_services.GetDashboardConfiguration(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        return answer

    def list_suricata_rules_sources(self):
        answer = self._stub_services.ListSuricataRulesSources(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        if 'sources' in answer:
            answer = answer['sources']
        return answer

    def _add_suricata_rules_source__with_params_list(self, name: str, url: str = None, params:List[str] = None):
        params_dict = None
        if params:
            params_dict = dict(map(lambda s: s.split('=', maxsplit=1), params))
        self.add_suricata_rules_source(name, url, params_dict)

    def add_suricata_rules_source(self, name: str, url: str = None, params:Dict[str,str] = None):
        add_request = SuricataRulesSource(name=name, url=url)
        if params:
            for (k, v) in params.items():
                add_request.parameters[k] = v
        answer = self._stub_services.AddSuricataRulesSource(add_request)

    def delete_suricata_rules_source(self, name: str):
        answer = self._stub_services.DeleteSuricataRulesSource(StringValue(value=name))

    def list_device_monitorings(self):
        answer = self._stub_services.ListDeviceMonitorings(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        if 'monitorings' in answer:
            answer = answer['monitorings']
        return answer

    def get_device_monitoring_template(self):
        answer = self._stub_services.GetDeviceMonitoringTemplate(EMPTY)
        answer = MessageToDict(answer, preserving_proto_field_name=True)
        example_name = answer.pop('name', None)
        return answer

    def add_device_monitoring_by_file_descriptor(self, name: str, yaml_file: TextIO):
        configuration = yaml.safe_load(yaml_file)
        self.add_device_monitoring(name, configuration)

    def add_device_monitoring(self, name: str, configuration: Dict):
        device_monitoring_data = dict()
        for (k, v) in configuration.items():
            if k == 'filters':
                filters = []
                for filter_item in v:
                    filter_request = DeviceMonitoringFilter(**filter_item)
                    filters.append(filter_request)
                device_monitoring_data['filters'] = filters
            else:
                device_monitoring_data[k] = v
        add_request = DeviceMonitoring(name=name, **device_monitoring_data)
        answer = self._stub_services.AddDeviceMonitoring(add_request)

    def delete_device_monitoring(self, name: str):
        answer = self._stub_services.DeleteDeviceMonitoring(StringValue(value=name))


class AccessAdapter(BaseAdapter):
    _stub_access: access_pb2_grpc.AccessStub
    _permission_str_regex = r"^(\+|-)?(\w+)(:(\w+))?$"

    def __init__(self, channel):
        super(AccessAdapter, self).__init__(channel)
        self._stub_access = access_pb2_grpc.AccessStub(channel)
        self._permission_str_regex = re.compile(self._permission_str_regex)

    def reset_administration_token(self):
        answer = self._stub_access.ResetAdministrationToken(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def get_administration_token(self):
        answer = self._stub_access.GetAdministrationToken(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def get_administration_certificate(self):
        answer = self._stub_access.GetAdministrationCertificate(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def get_administration_clis(self):
        answer = self._stub_access.GetAdministrationCLIs(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def create_user_access(self):
        answer = self._stub_access.CreateUserAccess(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def get_user_access(self, idx:int):
        idx_param = Int32Value()
        idx_param.value = int(idx)
        answer = self._stub_access.GetUserAccess(idx_param)
        answer = MessageToDict(answer)
        return answer

    def list_user_accesses(self):
        answer = self._stub_access.ListUserAccesses(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def delete_user_access(self, idx:int):
        idx_param = Int32Value()
        idx_param.value = int(idx)
        answer = self._stub_access.DeleteUserAccess(idx_param)

    def reset_user_access_token(self, idx:int):
        idx_param = Int32Value()
        idx_param.value = int(idx)
        answer = self._stub_access.ResetUserAccessToken(idx_param)
        answer = MessageToDict(answer)
        return answer

    def get_permission_list(self):
        answer = self._stub_access.GetPermissionList(EMPTY)
        answer = MessageToDict(answer)
        return answer

    def set_user_access_permissions(self, idx:int, permissions:List[str]):
        logger.debug("Permissions: %s", permissions)
        adds = ServiceAccess()
        removes = ServiceAccess()
        sets = ServiceAccess()
        for permission in permissions:
            match = self._permission_str_regex.match(permission)
            if match is None:
                logger.warning("Invalid permission: %s", permission)
                continue
            if match.group(1) is None:
                logger.debug("SET: %s:%s", match.group(2), match.group(4))
                sets.services[match.group(2)].permission.append(
                    match.group(4) if match.group(4) is not None else "all")
            if match.group(1) == '+':
                logger.debug("ADD: %s:%s", match.group(2), match.group(4))
                adds.services[match.group(2)].permission.append(
                    match.group(4) if match.group(4) is not None else "all")
            if match.group(1) == '-':
                logger.debug("DEL: %s:%s", match.group(2), match.group(4))
                removes.services[match.group(2)].permission.append(
                    match.group(4) if match.group(4) is not None else "all")

        query = PermissionChanges(user_access_idx=int(idx), adds=adds, removes=removes, sets=sets)

        answer = self._stub_access.SetUserAccessPermissions(query)
        answer = MessageToDict(answer)
        return answer

    def my_user_access(self):
        answer = self._stub_access.MyUserAccess(EMPTY)
        answer = MessageToDict(answer)
        return answer